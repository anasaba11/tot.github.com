import React, { useState, useEffect } from 'react';
import '../styles/chat.css';

export default function Chat() {
  const [conversations, setConversations] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    fetchConversations();
  }, []);

  const fetchConversations = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/chat/conversations', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setConversations(data.conversations || []);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const fetchMessages = async (conversationId) => {
    try {
      const response = await fetch(`http://localhost:5000/api/chat/${conversationId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setMessages(data.messages || []);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleSelectChat = (conversation) => {
    setSelectedChat(conversation);
    fetchMessages(conversation._id);
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedChat) return;

    try {
      await fetch(`http://localhost:5000/api/chat/${selectedChat._id}/send`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ text: newMessage })
      });
      setNewMessage('');
      fetchMessages(selectedChat._id);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div className="chat-container">
      <div className="conversations-list">
        <h2>محادثات</h2>
        {conversations.map(conv => (
          <div 
            key={conv._id} 
            className={`conversation-item ${selectedChat?._id === conv._id ? 'active' : ''}`}
            onClick={() => handleSelectChat(conv)}
          >
            <img src={conv.participants[0].avatar} alt="" />
            <div>
              <p className="conv-name">{conv.name}</p>
              <p className="conv-preview">{conv.lastMessage}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedChat && (
        <div className="chat-window">
          <div className="chat-header">
            <h3>{selectedChat.name}</h3>
          </div>

          <div className="messages-list">
            {messages.map(msg => (
              <div key={msg._id} className={`message ${msg.sender === localStorage.getItem('userId') ? 'sent' : 'received'}`}>
                <p>{msg.text}</p>
                <span className="time">{new Date(msg.createdAt).toLocaleTimeString('ar')}</span>
              </div>
            ))}
          </div>

          <div className="message-input-wrapper">
            <input 
              type="text" 
              placeholder="اكتب رسالتك..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <button onClick={handleSendMessage}>إرسال</button>
          </div>
        </div>
      )}
    </div>
  );
}