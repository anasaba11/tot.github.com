import React, { useState, useEffect } from 'react';
import '../styles/stories.css';

export default function Stories() {
  const [stories, setStories] = useState([]);

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/stories', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setStories(data.stories || []);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div className="stories-container">
      <div className="story-item add-story">
        <div className="story-avatar add-icon">+</div>
        <p>إضافة قصة</p>
      </div>

      {stories.map(story => (
        <div key={story._id} className="story-item" style={{
          backgroundImage: `url(${story.image})`
        }}>
          <div className="story-avatar">
            <img src={story.user.avatar} alt={story.user.username} />
          </div>
          <p>{story.user.username}</p>
        </div>
      ))}
    </div>
  );
}