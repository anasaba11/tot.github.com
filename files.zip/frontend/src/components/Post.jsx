import React, { useState } from 'react';
import '../styles/post.css';

export default function Post({ post, onRefresh }) {
  const [liked, setLiked] = useState(post.liked || false);
  const [likes, setLikes] = useState(post.likes || 0);
  const [showComments, setShowComments] = useState(false);
  const [comment, setComment] = useState('');

  const handleLike = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/posts/${post._id}/like`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setLiked(data.liked);
      setLikes(data.likes);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleAddComment = async () => {
    if (!comment.trim()) return;
    
    try {
      await fetch(`http://localhost:5000/api/posts/${post._id}/comment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ text: comment })
      });
      setComment('');
      onRefresh();
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div className="post-card">
      {/* رأس المنشور */}
      <div className="post-header">
        <div className="user-info">
          <img src={post.user.avatar} alt={post.user.username} className="avatar" />
          <div>
            <h4>{post.user.firstName} {post.user.lastName}</h4>
            <p className="username">@{post.user.username}</p>
            <span className="timestamp">{new Date(post.createdAt).toLocaleDateString('ar')}</span>
          </div>
        </div>
        <button className="menu-btn">⋯</button>
      </div>

      {/* المحتوى */}
      <div className="post-content">
        <p>{post.description}</p>
        {post.image && <img src={post.image} alt="Post" className="post-image" />}
        {post.fileUrl && (
          <a href={post.fileUrl} className="file-link" download>
            📁 {post.fileName}
          </a>
        )}
      </div>

      {/* الإحصائيات */}
      <div className="post-stats">
        <span>{likes} إعجابات</span>
        <span>{post.comments?.length || 0} تعليقات</span>
      </div>

      {/* الأزرار */}
      <div className="post-actions">
        <button 
          className={`action-btn ${liked ? 'active' : ''}`}
          onClick={handleLike}
        >
          ❤️ إعجاب
        </button>
        <button className="action-btn" onClick={() => setShowComments(!showComments)}>
          💬 تعليق
        </button>
        <button className="action-btn">
          📤 مشاركة
        </button>
      </div>

      {/* التعليقات */}
      {showComments && (
        <div className="comments-section">
          <div className="comments-list">
            {post.comments?.map(c => (
              <div key={c._id} className="comment">
                <strong>@{c.user.username}</strong>
                <p>{c.text}</p>
              </div>
            ))}
          </div>
          <div className="comment-input">
            <input 
              type="text" 
              placeholder="أضف تعليقاً..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
            <button onClick={handleAddComment}>إرسال</button>
          </div>
        </div>
      )}
    </div>
  );
}