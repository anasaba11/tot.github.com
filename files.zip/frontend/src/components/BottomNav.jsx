import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../styles/bottomnav.css';

export default function BottomNav() {
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="bottom-nav">
      <Link to="/home" className={`nav-item ${isActive('/home') ? 'active' : ''}`}>
        <span>🏠</span>
        <p>الرئيسية</p>
      </Link>
      
      <Link to="/assignments" className={`nav-item ${isActive('/assignments') ? 'active' : ''}`}>
        <span>📚</span>
        <p>الفروض</p>
      </Link>
      
      <Link to="/search" className={`nav-item ${isActive('/search') ? 'active' : ''}`}>
        <span>🔍</span>
        <p>البحث</p>
      </Link>
      
      <Link to="/chat" className={`nav-item ${isActive('/chat') ? 'active' : ''}`}>
        <span>💬</span>
        <p>الدردشة</p>
      </Link>
      
      <Link to="/profile" className={`nav-item ${isActive('/profile') ? 'active' : ''}`}>
        <span>👤</span>
        <p>الملف</p>
      </Link>
    </nav>
  );
}