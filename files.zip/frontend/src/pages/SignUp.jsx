import React, { useState } from 'react';
import '../styles/auth.css';

export default function SignUp() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    username: '',
    age: '',
    email: '',
    password: '',
    school: '',
    city: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem('token', data.token);
        window.location.href = '/home';
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h1 className="logo">EduSocial 📚</h1>
        <h2>انضم إلينا</h2>
        
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <input 
              type="text" 
              name="firstName" 
              placeholder="الاسم الشخصي"
              onChange={handleChange}
              required
            />
            <input 
              type="text" 
              name="lastName" 
              placeholder="النسب"
              onChange={handleChange}
              required
            />
          </div>

          <input 
            type="text" 
            name="username" 
            placeholder="اسم المستخدم"
            onChange={handleChange}
            required
          />

          <div className="form-row">
            <input 
              type="number" 
              name="age" 
              placeholder="العمر"
              onChange={handleChange}
              required
            />
            <input 
              type="email" 
              name="email" 
              placeholder="البريد الإلكتروني"
              onChange={handleChange}
              required
            />
          </div>

          <input 
            type="password" 
            name="password" 
            placeholder="كلمة المرور"
            onChange={handleChange}
            required
          />

          <div className="form-row">
            <input 
              type="text" 
              name="school" 
              placeholder="المدرسة"
              onChange={handleChange}
              required
            />
            <input 
              type="text" 
              name="city" 
              placeholder="المدينة"
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="btn-primary">
            إنشاء الحساب
          </button>
        </form>

        <p className="auth-link">
          لديك حساب؟ <a href="/login">تسجيل الدخول</a>
        </p>
      </div>
    </div>
  );
}