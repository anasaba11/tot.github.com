import React, { useState, useEffect } from 'react';
import '../styles/assignments.css';

export default function Assignments() {
  const [assignments, setAssignments] = useState([]);
  const [filter, setFilter] = useState('all');
  const [subjects] = useState(['الرياضيات', 'العربية', 'الإنجليزية', 'العلوم', 'التاريخ']);

  useEffect(() => {
    fetchAssignments();
  }, [filter]);

  const fetchAssignments = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/assignments?filter=${filter}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setAssignments(data.assignments || []);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div className="assignments-container">
      <div className="assignments-header">
        <h1>📝 الفروض والتمارين</h1>
        <button className="btn-upload">+ إضافة واجب</button>
      </div>

      <div className="filter-tabs">
        <button 
          className={`tab ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          الكل
        </button>
        <button 
          className={`tab ${filter === 'homework' ? 'active' : ''}`}
          onClick={() => setFilter('homework')}
        >
          فروض
        </button>
        <button 
          className={`tab ${filter === 'exercises' ? 'active' : ''}`}
          onClick={() => setFilter('exercises')}
        >
          تمارين
        </button>
      </div>

      <div className="assignments-list">
        {assignments.map(assignment => (
          <div key={assignment._id} className="assignment-card">
            <div className="assignment-header">
              <h3>{assignment.title}</h3>
              <span className="subject-badge">{assignment.subject}</span>
            </div>
            <p className="assignment-desc">{assignment.description}</p>
            <div className="assignment-meta">
              <span>📅 موعد التسليم: {new Date(assignment.dueDate).toLocaleDateString('ar')}</span>
              <span>📌 {assignment.type === 'homework' ? 'واجب منزلي' : 'تمرين'}</span>
            </div>
            <a href={assignment.fileUrl} className="download-link">⬇️ تحميل</a>
          </div>
        ))}
      </div>
    </div>
  );
}