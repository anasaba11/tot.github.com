import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Stories from '../components/Stories';
import Post from '../components/Post';
import BottomNav from '../components/BottomNav';
import '../styles/home.css';

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/posts', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setPosts(data.posts || []);
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="home-container">
      <Header />
      
      <div className="feed-wrapper">
        <Stories />
        
        <div className="feed">
          {loading ? (
            <p className="loading">جاري التحميل...</p>
          ) : posts.length === 0 ? (
            <p className="empty-state">لا توجد منشورات حالياً 📭</p>
          ) : (
            posts.map(post => <Post key={post._id} post={post} onRefresh={fetchPosts} />)
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}