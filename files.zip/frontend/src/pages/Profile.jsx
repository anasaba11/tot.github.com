import React, { useState, useEffect } from 'react';
import '../styles/profile.css';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/user/profile', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setUser(data.user);
      setPosts(data.posts || []);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  if (!user) return <p>جاري التحميل...</p>;

  return (
    <div className="profile-container">
      <div className="profile-header">
        <img src={user.avatar} alt={user.username} className="profile-avatar" />
        <div className="profile-info">
          <h2>{user.firstName} {user.lastName}</h2>
          <p>@{user.username}</p>
          <p className="school">📚 {user.school}</p>
          <p className="location">📍 {user.city}</p>
        </div>
      </div>

      <div className="profile-stats">
        <div className="stat">
          <h3>{posts.length}</h3>
          <p>منشورات</p>
        </div>
        <div className="stat">
          <h3>{user.friends?.length || 0}</h3>
          <p>أصدقاء</p>
        </div>
        <div className="stat">
          <h3>{user.followers?.length || 0}</h3>
          <p>متابعون</p>
        </div>
      </div>

      <button className="btn-edit">تعديل الملف</button>

      <div className="user-posts">
        <h3>المنشورات</h3>
        <div className="posts-grid">
          {posts.map(post => (
            <div key={post._id} className="post-thumbnail">
              {post.image && <img src={post.image} alt="Post" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}